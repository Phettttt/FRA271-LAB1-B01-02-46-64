% % ข้อมูล Sheild_south ทั้ง 3 รอบ
% V_out1 = [1.696, 1.729, 1.807, 1.943, 2.308, 3.279]; %รอบ1
% B_val1 = [0.07045, 0.06048, 0.1206, 0.225, 0.5058, 1.252]; %รอบ1
% 
% V_out2 = [1.688, 1.723, 1.783, 1.918, 2.183, 3.28]; %รอบ2
% B_val2 = [0.02939, 0.05646, 0.1019, 0.2063, 0.4096, 1.252]; %รอบ2
% 
% V_out3 = [1.694, 1.724, 1.783, 1.912, 2.231, 3.28]; %รอบ3
% B_val3 = [0.03391, 0.05701, 0.1024, 0.2016, 0.4467, 1.252]; %รอบ3
% 
% % หาค่าเฉลี่ย (Average) ของ V_out และ B_val
% V_avg = (V_out1 + V_out2 + V_out3) / 3;
% B_avg = (B_val1 + B_val2 + B_val3) / 3;

% % สร้างกราฟ V_avg เทียบ B_avg
% figure;
% plot(V_avg, B_avg, '-', 'LineWidth', 2);
% grid on;
% xlabel('shield south pole / V');
% ylabel('shield south pole / B');
% title('shield south pole avg');

% ข้อมูล Sheild_Nouth ทั้ง 3 รอบ
 % V_out1 = [1.576, 1.545, 1.485, 1.348, 1.016, 0.0811]; %รอบ1
 % B_val1 = [-0.05691,-0.0805, -0.1266, -0.2319, -0.4873, -1.206]; %รอบ1

%  V_out2 = [1.575, 1.543, 1.479, 1.358, 0.9952, 0.0783]; %รอบ2
%  B_val2 = [-0.5756,-0.08243, -0.1311, -0.226, -0.5032, -1.208]; %รอบ2
% 
% V_out3 = [1.573,1.542, 1.481, 1.343, 0.9793, 0.07628]; %รอบ3
% B_val3 = [-0.05904,-0.08303, -0.1299, -0.2358, -0.5154, -1.209]; %รอบ3
% 
% % หาค่าเฉลี่ย (Average) ของ V_out และ B_val
%  V_avg = (V_out1 + V_out2 + V_out3) / 3;
% B_avg = (B_val1 + B_val2 + B_val3) / 3;
%  % สร้างกราฟ V_avg เทียบ B_avg
%  figure;
% plot(V_avg, B_avg, '-', 'LineWidth', 2);
% grid on;
% xlabel('shield south pole / V');
% ylabel('shield south pole / B');
% title('shield south pole avg');

% ข้อมูล Sheild_south
V_out1 = [1.67, 1.694, 1.727, 1.806, 1.936, 2.272,3.28]; %รอบ1
B_val1 = [0.6786,1.453, 2.578,4.87, 9.526, 20.7,54.26]; %รอบ1

% ข้อมูล Sheild_Nouth
%V_out1 = [1.594, 1.575,1.537, 1.473, 1.322, 0.9794,0.07425]; %รอบ1
%B_val1 = [-1.847,-2.508, -3.766,-5.879, -10.92, -22.33,-52.46]; %รอบ1
figure;
 plot(V_out1, B_val1, '-', 'LineWidth', 2);
 grid on;
 xlabel('v avg Nouth');
ylabel('b avg Nouth');
 title('b avg Nouth vs. v avg Nouth');