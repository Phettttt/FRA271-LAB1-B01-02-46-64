plot(Integrator1.time(500:end), Integrator1.data(500:end), 'LineWidth', 1.5)
grid on
xlabel('Time (s)')
ylabel('Magnetic Flux Density (mT)')
title('Magnetic Sensor Response')
