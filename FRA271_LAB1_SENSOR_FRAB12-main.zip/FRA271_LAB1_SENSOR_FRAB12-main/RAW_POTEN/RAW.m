% ==========================================
% โค้ดพล็อตกราฟ Rotary Potentiometer (แกน Y 2 ฝั่ง: V และ %)
% ==========================================

% 1. แกน X (Rotational Travel 0-100%)
% deg = 0:5:100; 
% 
% % 2. ข้อมูลแกน Y (แรงดัน V)
% V_test = [0,0,0.3,0.79,1.12,1.67,2.1,2.39,2.73,2.76,2.82,2.88,2.94,2.99,3.03,3.08,3.13,3.19,3.25,3.29,3.29];
% V_percent = (V_test / 3.3) * 100;
% 
% figure('Name', 'Test Single Potentiometer', 'Color', 'w', 'Position', [100, 100, 700, 500]);
% 
% % ==========================================
% % สร้างแกน Y ฝั่งซ้าย (แรงดัน V)
% % ==========================================
% yyaxis left;
% plot(deg, V_test, '-', 'LineWidth', 2.5, 'Color', '#77AC30');%'#D95319' (สีส้ม) '#77AC30' (สีเขียว) #0072B (สีฟ้า)
% ylabel('Output Voltage (V)', 'FontSize', 12, 'FontWeight', 'bold');
% ylim([0 3.3]);
% yticks(linspace(0, 3.3, 11)); % แบ่ง 10 ช่อง (0, 0.33, 0.66 ... 3.3) ให้เส้นกริดทับกันพอดี
% 
% % ==========================================
% % สร้างแกน Y ฝั่งขวา (เปอร์เซ็นต์ %)
% % ==========================================
% yyaxis right;
% plot(deg, V_percent, '-', 'LineWidth', 2.5, 'Color', '#77AC30');%'#D95319' (สีส้ม) '#77AC30' (สีเขียว) #0072B (สีฟ้า)
% ylabel('Terminal 1-2 Output Voltage \times 100 (%)', 'FontSize', 12, 'FontWeight', 'bold');
% ylim([0 100]);
% yticks(0:10:100); % แบ่งสเกลทีละ 10% ตาม Datasheet

% ==========================================
% ตกแต่งความสวยงามและเส้นตาราง (Grid)
% ==========================================
% ax = gca;
% % เปลี่ยนสีแกน Y ทั้งสองฝั่งเป็นสีดำ (ค่าเริ่มต้นของ yyaxis เป็นสีฟ้า/ส้ม)
% ax.YAxis(1).Color = 'k';
% ax.YAxis(2).Color = 'k';
% 
% % ปรับแกน X ให้มีขีดทุกๆ 10% เหมือน Datasheet
% xlim([0 100]);
% xticks(0:10:100); 
% 
% % เปิดเส้นกริดและปรับความเข้ม
% grid on;
% ax.GridAlpha = 0.4;
% ax.FontSize = 11;
% 
% title('Test: Rotary Potentiometer (C Series Taper)', 'FontSize', 14, 'FontWeight', 'bold');
% xlabel('Rotational Travel (%,°)', 'FontSize', 12, 'FontWeight', 'bold');
%----------------------------------------------------------------------------------------------------


% ==========================================
% โค้ดพล็อตกราฟ Linear Potentiometer (แบบสไลด์ - Linear A)
% ==========================================

%1. แกน X (ระยะทาง Linear Travel หน่วย mm ตามที่จดค่ามา)
dist = [6, 12, 18, 24, 30, 36, 42, 48, 54, 60, 65]; 

% 2. ข้อมูลแกน Y (แรงดัน V) จากตาราง LINAR A รอบที่ 1
V_test = [0,0.15,0.51,0.87,1.23,1.6,1.99,2.36,2.72,3.11,3.29];

% แปลงเป็นเปอร์เซ็นต์ (อ้างอิงไฟเข้า 3.3V)
V_percent = (V_test / 3.3) * 100; 

figure('Name', 'Test Linear Potentiometer', 'Color', 'w', 'Position', [100, 100, 700, 500]);

% ==========================================
% สร้างแกน Y ฝั่งซ้าย (แรงดัน V)
% ==========================================
yyaxis left;
plot(dist, V_test, '-', 'LineWidth', 2.5, 'Color', '#D95319'); % ใช้เส้นสีเขียว
ylabel('Output Voltage (V)', 'FontSize', 12, 'FontWeight', 'bold');
ylim([0 3.3]);
yticks(linspace(0, 3.3, 11)); % แบ่ง 10 ช่อง

% ==========================================
% สร้างแกน Y ฝั่งขวา (เปอร์เซ็นต์ %)
% ==========================================
yyaxis right;
plot(dist, V_percent, '-', 'LineWidth', 2.5, 'Color', '#D95319');
ylabel('Output Voltage (%)', 'FontSize', 12, 'FontWeight', 'bold');
ylim([0 100]);
yticks(0:10:100); 

% ==========================================
% ตกแต่งความสวยงามและเส้นตาราง (Grid)
% ==========================================
ax = gca;
ax.YAxis(1).Color = 'k'; % เปลี่ยนสีตัวเลขแกน Y ซ้ายเป็นสีดำ
ax.YAxis(2).Color = 'k'; % เปลี่ยนสีตัวเลขแกน Y ขวาเป็นสีดำ

% ปรับขอบเขตแกน X ให้เป็นหน่วยระยะทาง (0-65 mm)
xlim([0 65]);
xticks(0:5:65); % ตีเส้นกริดแกน X ทุกๆ 5 mm

% เปิดเส้นกริด
grid on;
ax.GridAlpha = 0.4;
ax.FontSize = 11;

title('Test: Linear Potentiometer (Linear B)', 'FontSize', 14, 'FontWeight', 'bold');
xlabel('Linear Travel (mm)', 'FontSize', 12, 'FontWeight', 'bold');
% ---------------------------------------------------------------------------------------


% ==========================================
% โค้ดพล็อตกราฟ Schmitt Trigger (Analog vs Digital)
% ==========================================

% 1. ดึงข้อมูลเวลา (Time) และแรงดัน/สถานะ (Data) จากตัวแปร timeseries
% t_analog = LinearA_Analogl_2.Time;
% v_analog = LinearA_Analogl_2.Data;
% 
% t_digital = LinearA_Digital_2.Time;
% v_digital = LinearA_Digital_2.Data;
% 
% % 2. สร้างหน้าต่างกราฟ
% figure('Name', 'Schmitt Trigger Response', 'Color', 'w', 'Position', [100, 100, 800, 450]);
% 
% % ==========================================
% % พล็อตเส้นสัญญาณ Analog (แกน Y ฝั่งซ้าย)
% % ==========================================
% yyaxis left;
% plot(t_analog, v_analog, '-', 'LineWidth', 2.5, 'Color', '#D95319'); % สีส้ม
% ylabel('Analog Input Voltage (V)', 'FontSize', 12, 'FontWeight', 'bold');
% ylim([0 3.5]); % ล็อกสเกลแรงดันไว้ที่ 0 - 3.5V

% ==========================================
% พล็อตเส้นสัญญาณ Digital (แกน Y ฝั่งขวา)
% ==========================================
% yyaxis right;
% plot(t_digital, v_digital, '-', 'LineWidth', 2.5, 'Color', '#0072BD'); % สีฟ้า
% ylabel('Digital Output (Logic 0 / 1)', 'FontSize', 12, 'FontWeight', 'bold');
% ylim([-0.2 1.5]); % เผื่อพื้นที่ด้านบนและล่างให้เส้น Digital ไม่ติดขอบกราฟ
% yticks([0 1]); % กำหนดให้แกน Y โชว์แค่เลข 0 กับ 1
% 
% % ==========================================
% % ตกแต่งความสวยงามของกราฟ
% % ==========================================
% ax = gca;
% ax.YAxis(1).Color = '#D95319'; % เปลี่ยนสีตัวเลขแกนซ้ายให้ตรงกับเส้นส้ม
% ax.YAxis(2).Color = '#0072BD'; % เปลี่ยนสีตัวเลขแกนขวาให้ตรงกับเส้นฟ้า
% 
% grid on;
% ax.GridAlpha = 0.4;
% ax.FontSize = 11;
% 
% title('Schmitt Trigger Response (Linear B)', 'FontSize', 14, 'FontWeight', 'bold');
% xlabel('Time (Seconds)', 'FontSize', 12, 'FontWeight', 'bold');