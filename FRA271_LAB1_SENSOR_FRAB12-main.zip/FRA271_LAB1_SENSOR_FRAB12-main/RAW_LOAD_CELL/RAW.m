% 1. ใส่ข้อมูลแกน X (น้ำหนัก หรือ นิวตัน)
% 1. ข้อมูลแกน X (น้ำหนัก หรือ นิวตัน)
Weight_kg = [0.308,1.289,2.278,3.294,4.293,5.059,6.319,6.65,7.48,8.402,9.56]; 

% 2. ข้อมูลแกน Y (แรงดัน V และ นิวตัน N)
V_Loading = [0.244,0.49,0.747,0.994,1.235,1.502,1.743,1.998,2.244,2.502,2.514];
Weight_Newton = [3.544,13.83,23.97,34.46,44.48,55.36,65.34,75.79,86.15,96.85,97.4];

% 3. คำสั่งสร้างกราฟ 2 แกน
figure('Color', 'w'); % พื้นหลังสีขาวดูสะอาดตา

% --- แกนฝั่งซ้าย (แรงดัน V) ---
yyaxis left;
plot(Weight_kg, V_Loading, '-ob', 'LineWidth', 2, 'MarkerSize', 6, 'MarkerFaceColor', 'b');
ylabel('Output Voltage (V)', 'FontSize', 12, 'FontWeight', 'bold');
ylim([0, 3]); % ล็อกสเกลให้ดูสวยงาม

% --- แกนฝั่งขวา (แรง N) ---
yyaxis right;
plot(Weight_kg, Weight_Newton, '--sr', 'LineWidth', 2, 'MarkerSize', 6, 'MarkerFaceColor', 'r');
ylabel('Calculated Force (N)', 'FontSize', 12, 'FontWeight', 'bold');
ylim([0, 120]); % ล็อกสเกลให้ล้อไปกับแกนซ้าย

% 4. ตกแต่งกราฟให้สวยงาม
title('Load Cell Linearity and Saturation Curve', 'FontSize', 14, 'FontWeight', 'bold');
xlabel('Applied Mass (kg)', 'FontSize', 12, 'FontWeight', 'bold');
legend('Voltage (V)', 'Force (N)', 'Location', 'northwest', 'FontSize', 11);
grid on;
% ---------------------------------------------------------------------------

% แรงดัน realtime-
% พลอตแบบ realtime
% สร้างหน้าต่างกราฟพื้นหลังสีขาว
% figure('Color', 'w'); 
% 
% % แกนฝั่งซ้าย (Voltage)
% yyaxis left
% plot(out.tout, squeeze(out.sim_voltage), 'LineWidth', 1.5);
% ylabel('Output Voltage (V)', 'FontWeight', 'bold');
% 
% % แกนฝั่งขวา (Force in Newton)
% yyaxis right
% plot(out.tout, squeeze(out.sim_newton), 'LineWidth', 1.5);
% ylabel('Applied Force (N)', 'FontWeight', 'bold');
% 
% % ตกแต่งทั่วไป (แกน X, ชื่อกราฟ, Legend, และ Grid)
% xlabel('Time (s)', 'FontWeight', 'bold');
% title('Real-Time Load Cell Response');
% legend('Voltage (V)', 'Force (N)', 'Location', 'northwest');
% grid on; % เปิดเส้นตารางหลักแบบคลีนๆ