% % 1. ดึงข้อมูลเวลาและค่าการกระจัดจากตัวแปร SimulationOutput (out)
% t = out.simout.Time;
% x = out.simout.Data;
% 
% % 2. สร้างกราฟและพล็อตเส้น 
% % ปรับความหนาของเส้นและเปลี่ยนสีเป็นสีส้มตามรูปตัวอย่าง
% figure;
% plot(t, x, 'Color', '#FF5722', 'LineWidth', 4); 
% 
% % 3. การตั้งค่า Format รูปแบบกราฟ
% grid on;
% grid minor;
% set(gca, 'FontSize', 16);
% set(gca, 'LineWidth', 1.5);
% 
% % เปิดกรอบกราฟและตั้งค่าขีดสเกล (Tick) ให้ชี้เข้าด้านใน
% box on;
% set(gca, 'TickDir', 'in', 'TickLength', [0.015 0.015]); 
% 
% % บังคับช่วงของแกน X และ Y พร้อมกำหนดสเกลทีละ 1 สเตป
% xlim([0 10]);
% xticks(0:1:10);
% ylim([-5 5]);
% yticks(-5:1:5);
% 
% % กำหนดชื่อแกน
% xlabel('Time (t)', 'FontSize', 16);
% ylabel('Displacement (x)', 'FontSize', 16);

% เพิ่มข้อความด้านบน (Constant Amplitude)
%text(8, 4.8, '(Constant Amplitude)', 'FontSize', 18, ...
 %   'BackgroundColor', 'w', 'HorizontalAlignment', 'center', 'Margin', 10);

% เพิ่มข้อความด้านล่าง (การสั่นแบบไร้ตัวหน่วง)
%text(8, -5, {'การสั่นแบบไร้ตัวหน่วง', '(Undamped Oscillation)'}, 'FontSize', 18, ...
   % 'BackgroundColor', 'w', 'HorizontalAlignment', 'center', 'Margin', 10);

   % % 1. ประกาศตัวแปรเชิงสัญลักษณ์
   % syms x(t) m k F
   % % 2. ตั ้งสมการ ODE (Equation of Motion)
   % eqn = m*diff(x, t, 2) + k*x == F;
   % dx = diff(x, t); % ก าหนดตัวแปรความเร็ว
   % % 3. ก าหนดเงื่อนไขเริ่มต้น (Initial Conditions)
   % cond1=x(0) == 5; % ระยะเริ่มต้น (Initial Position) = 5
   % cond2 = dx(0) == 0;% ความเร็วเริ่มต้น (Initial Velocity) = 0
   % conds = [cond1, cond2];
   % % 4. สั่งแก้สมการหาผลเฉลย
   % sol_x = dsolve(eqn, conds)
   % 
   % % 5. ก าหนดค่าพารามิเตอร์ทางกายภาพให้กับระบบ
   % m_val = 1;  % มวล (kg)
   % k_val = 10; % ค่านิจสปริง (N/m)
   % F_val = 0;  % แรงภายนอก (N) - ก าหนดเป็น 0 ส าหรับระบบที่สั่นอย่างอิสระ (Free Vibration)
   % % แทนค่าพารามิเตอร์ [m, k, F] ลงในผลเฉลย sol_x ด้วยค าสั่ง subs
   % sol_x_numeric = subs(sol_x, [m, k, F], [m_val, k_val, F_val]);
   % dx = diff(x, t); % ก าหนดตัวแปรความเร็ว
   % % ใช้ fplot เพื่อวาดกราฟสัญลักษณ์ โดยก าหนดช่วงเวลา t = 0 ถึง 10 วินาที
   % fplot(sol_x_numeric, [0, 10], 'b-', 'LineWidth', 1.5);
   % grid on;
   % title('System Response: Displacement vs Time');
   % xlabel('Time, t (s)');
   % ylabel('Displacement, x(t) (m)');

   % 1. ประกาศตัวแปรเชิงสัญลักษณ์
   syms x(t) zeta wn t
   % 2. ตั ้งสมการ ODE (Equation of Motion)
   eqn = diff(x, t, 2) + 2*zeta*wn*diff(x, t) + wn^2*x == 0;
   dx = diff(x, t); % ก าหนดตัวแปรความเร็ว
   % 3. ก าหนดเงื่อนไขเริ่มต้น (Initial Conditions)
   conds = [x(0) == 1, dx(0) == 0];
   % 4. สั่งแก้สมการหาผลเฉลย
   under = subs(eqn, [wn, zeta], [10, 0.2]);
   x_under = dsolve(under, conds);
   crit = subs(eqn, [wn, zeta], [10, 1.0]);
   x_crit = dsolve(crit, conds);
   over = subs(eqn, [wn, zeta], [10, 2.0]);
   x_over = dsolve(over, conds);



    fplot(x_under, [0, 10], 'b-', 'LineWidth', 1.5);
    hold on;
  %  fplot(x_crit, [0, 10], 'r-', 'LineWidth', 1.5);
   % fplot(x_over, [0, 10], 'g-', 'LineWidth', 1.5);
    xlim([0 10]);
    xticks(0:1:10);
    ylim([-1 1]);
    yticks(-1:1:1);
    
    
    grid on;
     title('System Response: Displacement vs Time');
     xlabel('Time, t (s)');
     ylabel('Displacement, x(t) (m)');
  