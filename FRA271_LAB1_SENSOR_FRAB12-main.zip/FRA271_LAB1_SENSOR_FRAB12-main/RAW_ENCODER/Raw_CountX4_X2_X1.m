% % --- โค้ดปรับแต่งกราฟอัตโนมัติ (ตัดช่วงแรก และเริ่มที่ 0 พร้อมกัน) ---
% 
% % 1. แปลงค่าที่กระโดด (Wrap-around 65536) ให้เป็นค่าที่ถูกต้อง
% D1 = Data_X1; D1(D1 > 32768) = D1(D1 > 32768) - 65536;
% D2 = Data_X2; D2(D2 > 32768) = D2(D2 > 32768) - 65536;
% D4 = Data_X4; D4(D4 > 32768) = D4(D4 > 32768) - 65536;
% 
% % 2. หาจุด (Index) แรกที่เริ่มมีการหมุนแกน (เพื่อตัดช่วงเวลาที่จอดนิ่งทิ้ง)
% idx1 = find(abs(D1 - D1(1)) > 0, 1); if isempty(idx1), idx1 = 1; end
% idx2 = find(abs(D2 - D2(1)) > 0, 1); if isempty(idx2), idx2 = 1; end
% idx4 = find(abs(D4 - D4(1)) > 0, 1); if isempty(idx4), idx4 = 1; end
% 
% % 3. ตัดเวลาช่วงแรกทิ้ง เลื่อนแกนเวลาให้มาเริ่มที่ 0 วินาที
% T1 = Time_X1(idx1:end) - Time_X1(idx1);
% T2 = Time_X2(idx2:end) - Time_X2(idx2);
% T4 = Time_X4(idx4:end) - Time_X4(idx4);
% 
% % 4. ปรับค่าการนับให้เริ่มที่ 0 และทำให้เป็นกราฟพุ่งขึ้น (abs) เพื่อเปรียบเทียบความชัน
% Val1 = abs(D1(idx1:end) - D1(idx1));
% Val2 = abs(D2(idx2:end) - D2(idx2));
% Val4 = abs(D4(idx4:end) - D4(idx4));
% 
% % --- สร้างและตกแต่งกราฟ ---
% figure('Color', 'w');
% plot(T1, Val1, 'r', 'LineWidth', 2); hold on;
% plot(T2, Val2, 'g', 'LineWidth', 2);
% plot(T4, Val4, 'b', 'LineWidth', 2);
% 
% title('การทดลองที่ 2: เปรียบเทียบความละเอียดการนับโหมด X1, X2, X4', 'FontSize', 14);
% xlabel('เวลา (วินาที)', 'FontSize', 12);
% ylabel('จำนวน Ticks (Pulse)', 'FontSize', 12);
% legend('Mode X1 (1000 PPR)', 'Mode X2 (2000 PPR)', 'Mode X4 (4000 PPR)', 'Location', 'best');
% grid on;

% --- โค้ดปรับแต่งกราฟอัตโนมัติ (ใช้ตัวแปรรอบแก้ตัว _1) ---

% 1. ดึงข้อมูลจาก Workspace (ตรวจสอบชื่อตัวแปรให้ตรงกับที่เซฟมา)
% D1 = Data_X1_2;   % ใช้ข้อมูล X1 รอบแก้ตัว
% D2 = Data_X2_2;   % ใช้ข้อมูล X2 รอบแก้ตัว
% D4 = Data_X4_2;     % ใช้ข้อมูล X4 เดิม (ถ้าคุณมี Data_X4_1 ให้แก้เลขตรงนี้ด้วยครับ)
% 
% T_1 = Time_X1_2;
% T_2 = Time_X2_2;
% T_4 = Time_X4_2;    % ใช้เวลา X4 เดิม (ถ้าคุณมี Time_X4_1 ให้แก้เลขตรงนี้ด้วยครับ)
% 
% % 2. แปลงค่าที่กระโดด (Wrap-around 65536) ให้เป็นค่าที่ต่อเนื่อง
% D1(D1 > 32768) = D1(D1 > 32768) - 65536;
% D2(D2 > 32768) = D2(D2 > 32768) - 65536;
% D4(D4 > 32768) = D4(D4 > 32768) - 65536;
% 
% % 3. หาจุด (Index) แรกที่เริ่มมีการหมุนแกน (เพื่อตัดช่วงเวลาที่จอดนิ่งทิ้ง)
% idx1 = find(abs(D1 - D1(1)) > 0, 1); if isempty(idx1), idx1 = 1; end
% idx2 = find(abs(D2 - D2(1)) > 0, 1); if isempty(idx2), idx2 = 1; end
% idx4 = find(abs(D4 - D4(1)) > 0, 1); if isempty(idx4), idx4 = 1; end
% 
% % 4. ตัดเวลาช่วงแรกทิ้ง เลื่อนแกนเวลาให้มาเริ่มที่ 0 วินาทีพร้อมกัน
% Time1_plot = T_1(idx1:end) - T_1(idx1);
% Time2_plot = T_2(idx2:end) - T_2(idx2);
% Time4_plot = T_4(idx4:end) - T_4(idx4);
% 
% % 5. ปรับค่าการนับให้เริ่มที่ 0 และทำให้เป็นกราฟพุ่งขึ้น (abs) เพื่อเปรียบเทียบความชัน
% Val1_plot = abs(D1(idx1:end) - D1(idx1));
% Val2_plot = abs(D2(idx2:end) - D2(idx2));
% Val4_plot = abs(D4(idx4:end) - D4(idx4));
% 
% % --- สร้างและตกแต่งกราฟ ---
% figure('Color', 'w');
% plot(Time1_plot, Val1_plot, 'r', 'LineWidth', 2); hold on;
% plot(Time2_plot, Val2_plot, 'g', 'LineWidth', 2);
% plot(Time4_plot, Val4_plot, 'b', 'LineWidth', 2);
% 
% title('การทดลองที่ 2: เปรียบเทียบความละเอียดการนับโหมด X1, X2, X4', 'FontSize', 14);
% xlabel('เวลา (วินาที)', 'FontSize', 12);
% ylabel('จำนวน Ticks (Pulse)', 'FontSize', 12);
% legend('Mode X1 (1000 PPR)', 'Mode X2 (2000 PPR)', 'Mode X4 (4000 PPR)', 'Location', 'best');
% grid on;

% กำหนดเวลาที่ต้องการตัดทิ้ง (จากกราฟคือเส้นพุ่งเสร็จสิ้นที่ประมาณ 2.5 วินาที)
% กำหนดเวลาที่ต้องการสิ้นสุด (ตัดกราฟช่วงที่ตกตอนท้ายออก)
% กำหนดเวลาที่ต้องการตัดทิ้งช่วงแรก (ตัด 1 วินาทีแรกออก)
% กำหนดเวลาตัดหัว-ท้าย 
t_start = 1.8; % ตัด 1.2 วินาทีแรกออก
t_end = 10.5;  % ตัดกราฟหลัง 13.5 วินาทีออก

figure('Color', 'w');
hold on;

% จัดการข้อมูล X1 (ตัดเวลา + ชิฟต์แกน Y ให้เริ่มที่ 0)
idx1 = (Data_X1.Time >= t_start) & (Data_X1.Time <= t_end);
time_X1 = Data_X1.Time(idx1) - Data_X1.Time(find(idx1, 1)); 
data_X1 = Data_X1.Data(idx1) - Data_X1.Data(find(idx1, 1)); 
plot(time_X1, data_X1, 'r', 'LineWidth', 2);

% จัดการข้อมูล X2 (ตัดเวลา + ชิฟต์แกน Y ให้เริ่มที่ 0)
idx2 = (Data_X2.Time >= t_start) & (Data_X2.Time <= t_end);
time_X2 = Data_X2.Time(idx2) - Data_X2.Time(find(idx2, 1));
data_X2 = Data_X2.Data(idx2) - Data_X2.Data(find(idx2, 1)); 
plot(time_X2, data_X2, 'g', 'LineWidth', 2);

% จัดการข้อมูล X4 (ตัดเวลา + ชิฟต์แกน Y ให้เริ่มที่ 0)
idx3 = (Data_X4.Time >= t_start) & (Data_X4.Time <= t_end);
time_X4 = Data_X4.Time(idx3) - Data_X4.Time(find(idx3, 1));
data_X4 = Data_X4.Data(idx3) - Data_X4.Data(find(idx3, 1)); 
plot(time_X4, data_X4, 'b', 'LineWidth', 2);

title('การทดลองที่ 2: เปรียบเทียบความละเอียดการนับโหมด X1, X2, X4');
xlabel('เวลา (วินาที)');
ylabel('จำนวน Ticks (Pulse)');
grid on;

% บังคับให้แกน X แสดงผลพอดีกับข้อมูลที่ถูกตัด
xlim([0, time_X4(end)]); 

legend('Mode X1 (2048 PPR)', 'Mode X2 (4096 PPR)', 'Mode X4 (8192 PPR)', 'Location', 'northwest');