% กำหนดจำนวนข้อมูลช่วงแรกที่ต้องการตัดทิ้ง (หลบช่วงกราฟกระตุกตอนเริ่ม)
idx = 10; 

% สร้างตัวแปรใหม่ที่ตัดข้อมูล 10 ค่าแรกออกไปแล้ว
Time_Clean = Time_Homing(idx:end);
Deg_Clean = Deg_Homing(idx:end);

% พล็อตกราฟใหม่
figure('Name', 'Homing Sequence (Cleaned)', 'Color', 'w', 'Position', [100, 100, 800, 400]);

plot(Time_Clean, Deg_Clean, 'b', 'LineWidth', 1.5);
title('การทดสอบ Homing Sequence (การตั้งค่าจุดอ้างอิงศูนย์)', 'FontSize', 12);
xlabel('เวลา (วินาที)', 'FontSize', 11);
ylabel('มุม (องศา)', 'FontSize', 11);
grid on;

% บังคับซูมแกน Y ให้อยู่ในช่วง -50 ถึง 200 องศา (เพราะกราฟสูงสุดอยู่ราวๆ 160)
ylim([-50 200]);