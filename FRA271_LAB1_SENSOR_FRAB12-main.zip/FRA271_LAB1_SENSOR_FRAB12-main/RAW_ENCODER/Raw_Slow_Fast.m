% ==========================================
% โค้ดแก้ปัญหากราฟกระโดด (Shift ค่าให้เริ่มที่ 0 องศา)
% ==========================================

% ข้ามข้อมูล 10 ค่าแรกทิ้ง เพื่อหลบจังหวะสัญญาณกระตุกตอนกด Run
idx = 100; 

% --- จัดการข้อมูล หมุนช้า (Slow) ---
Time_Slow_Clean = Time_B_Slow(idx:end) - Time_B_Slow(idx); % เลื่อนเวลามาเริ่ม 0
Deg_Slow_Clean = Deg_B_Slow(idx:end) - Deg_B_Slow(idx);    % หักลบค่าเริ่มต้นให้เป็น 0

% --- จัดการข้อมูล หมุนเร็ว (Fast) ---
Time_Fast_Clean = Time_B_Fast(idx:end) - Time_B_Fast(idx); % เลื่อนเวลามาเริ่ม 0
Deg_Fast_Clean = Deg_B_Fast(idx:end) - Deg_B_Fast(idx);    % หักลบค่าเริ่มต้นให้เป็น 0

% --- พล็อตกราฟเปรียบเทียบ ---
figure('Name', 'BOURNS Encoder: Cleaned Signal', 'Color', 'w', 'Position', [100, 100, 800, 500]);

% กราฟ 1: หมุนช้า
subplot(2, 1, 1);
plot(Time_Slow_Clean, Deg_Slow_Clean, 'b', 'LineWidth', 1.5);
title('คุณภาพสัญญาณน๊อบ BOURNS (Mechanical): หมุนช้า', 'FontSize', 12);
ylabel('มุม (องศา)', 'FontSize', 11);
grid on;

% กราฟ 2: หมุนเร็ว
subplot(2, 1, 2);
plot(Time_Fast_Clean, Deg_Fast_Clean, 'r', 'LineWidth', 1.5);
title('คุณภาพสัญญาณน๊อบ BOURNS (Mechanical): หมุนเร็ว', 'FontSize', 12);
xlabel('เวลา (วินาที)', 'FontSize', 11);
ylabel('มุม (องศา)', 'FontSize', 11);
grid on;