% ==========================================
% 1. สร้างหน้าต่างกราฟ ทิศทาง CW (ตามเข็มนาฬิกา)
% ==========================================
figure('Name', 'CW Direction', 'Color', 'w');

% กราฟบน: ตำแหน่งเชิงมุม (0-360 องศา)
subplot(2, 1, 1);
plot(Time_CW, Deg_CW, 'b', 'LineWidth', 1.5);
title('การทดลองที่ 3: ตำแหน่งเชิงมุม (Wrap-around 0-360) - ทิศทาง CW', 'FontSize', 12);
ylabel('มุม (องศา)', 'FontSize', 11);
grid on;

% กราฟล่าง: ความเร็วรอบ (RPM)
subplot(2, 1, 2);
plot(Time_CW, Vel_CW, 'r', 'LineWidth', 1.5);
title('ความเร็วรอบ - ทิศทาง CW', 'FontSize', 12);
xlabel('เวลา (วินาที)', 'FontSize', 11);
ylabel('ความเร็ว (RPM)', 'FontSize', 11);
grid on;

% ==========================================
% 2. สร้างหน้าต่างกราฟ ทิศทาง CCW (ทวนเข็มนาฬิกา)
% ==========================================
figure('Name', 'CCW Direction', 'Color', 'w');

% กราฟบน: ตำแหน่งเชิงมุม (0-360 องศา)
subplot(2, 1, 1);
plot(Time_CCW, Deg_CCW, 'b', 'LineWidth', 1.5);
title('การทดลองที่ 3: ตำแหน่งเชิงมุม (Wrap-around 0-360) - ทิศทาง CCW', 'FontSize', 12);
ylabel('มุม (องศา)', 'FontSize', 11);
grid on;

% กราฟล่าง: ความเร็วรอบ (RPM)
subplot(2, 1, 2);
plot(Time_CCW, Vel_CCW, 'r', 'LineWidth', 1.5);
title('ความเร็วรอบ - ทิศทาง CCW', 'FontSize', 12);
xlabel('เวลา (วินาที)', 'FontSize', 11);
ylabel('ความเร็ว (RPM)', 'FontSize', 11);
grid on;