% 1. ดึงข้อมูลเวลาและค่าสัญญาณ
t = out.PhaseA.Time;
valA = double(out.PhaseA.Data(:) > 2000); 
valB = double(out.PhaseB.Data(:) > 2000);

% 2. สร้างหน้าต่างกราฟ
figure('Color', 'w'); 

% 3. ใช้ stairs แทน plot เพื่อให้กราฟตั้งฉากเป็น Square Wave
stairs(t, valA, 'b', 'LineWidth', 1.5);
hold on;
stairs(t, valB - 1.5, 'r', 'LineWidth', 1.5);

% 4. ตกแต่งกราฟและกำหนดช่วงเวลาซูม
ylim([-2 1.5]); 
xlim([2.0, 2.05]); % <-- เปลี่ยนเลขตรงนี้เพื่อหาช่วงที่หมุน CW และ CCW
title('การทดลองที่ 1: Phase Relationship (ทิศทาง CW และ CCW)', 'FontSize', 14);
xlabel('เวลา (วินาที)', 'FontSize', 12);
ylabel('ลอจิก (Logic Level)', 'FontSize', 12);
legend('Phase A', 'Phase B', 'Location', 'best');
grid on;